# Contributors

Name | Role
 --- | --- 
Hedvig Skirgård | author
Hannah J. Haynie | author
Harald Hammarström | author
Russell Barlow | author
Damián E. Blasi | author
Jeremy Collins | author
Jay Latarche | author
Jakob Lesage | author
Tobias Weber | author
Alena Witzlack-Makarevich | author
Michael Dunn | author
Ger Reesink | author
Ruth Singer | author
Johannes Englisch | author
Angela Chira | author
Annemarie Verkerk | author
Russell Dinnage | author
Luke Maurits | author
Sam Passmore | author
Claire Bowern | author
Patience Epps | author
Jane Hill | author
Outi Vesakoski | author
Noor Karolin Abbas | author
Sunny Ananth | author
Daniel Auer | author
Nancy A. Bakker | author
Giulia Barbos | author
Anina Bolls | author
Robert D. Borges | author
Mitchell Browen | author
Hoju Cha 차호주 | author
Lennart Chevallier | author
Swintha Danielsen | author
Hugo de Vos | author
Sinoël Dohlen | author
Luise Dorenbusch | author
Ella Dorn | author
Marie Duhamel | author
Farah El Haj Ali | author
John Elliott | author
Grace Ephraums | author
Giada Falcone | author
Anna-Maria Fehn | author
Jana Fischer | author
Yustinus Ghanggo Ate | author
Hannah Gibson | author
Hans-Philipp Göbel | author
Jemima A. Goodall | author
Samuel Griggs | author
Victoria Gruner | author
Andrew Harvey | author
Rebekah Hayes | author
Leonard Heer | author
Roberto E. Herrera Miranda | author
Nataliia Hübler | author
Biu H. Huntington-Rainey | author
Guglielmo Inglese | author
Jessica K. Ivani | author
Marilen Johns | author
Erika Just | author
Ivan Kapitonov | author
Eri Kashima | author
Carolina Kipf | author
Janina V. Klingenberg | author
Nikita König | author
Aikaterina Koti | author
Richard G. A. Kowalik | author
Olga Krasnoukhova | author
Kate Lynn Lindsey | author
Nora  L. M. Lindvall | author
Mandy Lorenzen | author
Hannah Lutzenberger | author
Manuel Rüdisühli | author
Alexandra Marley | author
Tânia R. A. Martins | author
Marvin Leonard Martiny | author
Celia Mata German | author
Suzanne van der Meer | author
Jacob Menschel | author
Jaime Montoya | author
Michael Müller | author
Saliha Muradoglu | author
 HunterGatherer | author
David Nash | author
Kelsey Neely | author
Johanna Nickel | author
Miina Norvik | author
Olga Olina | author
Bruno Olsson | author
Cheryl Akinyi Oluoch | author
David Osgarby | author
Leah Pappas | author
Jesse Peacock | author
India O.C. Pearey | author
Naomi Peck | author
Jana Peter | author
Stephanie Petit | author
Sören Pieper | author
Mariana Poblete | author
Daniel Prestipino | author
Linda Raabe | author
Amna Raja | author
Tihomir Rangelov | author
Janis Reimringer | author
Sydney C. Rey | author
Julia Rizaew | author
Kristian Roncero Toledo | author
Eloisa Ruppert | author
Kim K. Salmon | author
Jill Sammet | author
Rhiannon Schembri | author
Lars Schlabbach | author
Frederick W. P. Schmidt | author
Dineke Schokkin | author
Jeff Siegel | author
Jane Simpson | author
Amalia Skilton | author
Hilário de Sousa | author
Kristin Sverredal | author
Daniel Valle | author
Javier Vera | author
Judith Voß | author
Daniel Wikalier Smith | author
Nicholas Williams | author
Tim Witte | author
Henry Wu | author
Stephanie Yam | author
Jingting Ye 葉婧婷 | author
Maisie Yong | author
Tessa Yuditha | author
Roberto Zariquiey | author
Olena Shcherbakova | author
Robert Forkel | author
Nicholas Evans | author
Stephen C. Levinson | author
Martin Haspelmath | author
Simon J. Greenhill | author
Quentin D. Atkinson | author
Russell D. Gray | author
